//
//  RestaurantListViewController.swift
//  YogiyoCodingTest
//
//  Created by Jun on 2018. 2. 19..
//  Copyright © 2018년 Yogiyo. All rights reserved.
//

import UIKit

class RestaurantListViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    var jsonArr:Array! = []
    var tableDataDic:Dictionary! = [String:Array<Any>]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let path = Bundle.main.path(forResource: "restaurants", ofType: "json")!
        let url = URL(fileURLWithPath: path)
        let jsonData = try! Data(contentsOf: url)
        // jsonData 를 활용하여 목록을 구성하시면 됩니다.
        
        
        if let data = self.convertToDictionary(jsonData: jsonData) {
            self.jsonArr = data
            self.tableDataDic = self.makeTableDataDic(jsonArr: self.jsonArr)
        } else {
            //json 파싱 실패!!!
            //TODO: 실패처리
        }
        
        self.tableView.register(UINib(nibName: "CustomTableViewCeltTableViewCell", bundle: nil), forCellReuseIdentifier: "TableViewCell");
        
    }
    
    func convertToDictionary(jsonData: Data) -> Array<Any>? {
        do {
            return try JSONSerialization.jsonObject(with: jsonData, options: []) as! Array<Any>
        } catch {
            print(error.localizedDescription)
            return nil
        }
    }
    
    func makeTableDataDic(jsonArr: Array<Any>) -> Dictionary<String, Array<Any>> {
        var tableDataDic = [String:Array<Any>]()
        
        for arg in jsonArr {
            guard let argDic = arg as? Dictionary<String, Any> else {
                print("Bad data.")
                break;
            }
            
            guard let sectionTitle = argDic["sectionTitle"] as? String else {
                print("Bad data.")
                break;
            }
            
            if var sectionArr = tableDataDic[sectionTitle] {    //기존 섹션에 저장
                sectionArr.append(argDic)
                tableDataDic.updateValue(sectionArr, forKey: sectionTitle)
                
            } else {    //섹션 생성
                tableDataDic.updateValue([argDic], forKey: sectionTitle)
            }
        }
        
        return tableDataDic
    }
}

// MARK: UITableViewDelegate
extension RestaurantListViewController: UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("didSelectRowAt: \(indexPath)")
        
    }
}

// MARK: UITableViewDataSource
extension RestaurantListViewController: UITableViewDataSource {

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell:CustomTableViewCeltTableViewCell! = self.tableView.dequeueReusableCell(withIdentifier: "TableViewCell", for: indexPath) as? CustomTableViewCeltTableViewCell
        cell.selectionStyle = .none
        
        let tableDataDicKeys = Array(self.tableDataDic.keys)
        guard let dataArr = self.tableDataDic[tableDataDicKeys[indexPath.section]] else { return cell }
        guard let dataDic = dataArr[indexPath.row] as? Dictionary<String, Any> else { return cell }
        
        //image mapping
        let imageUrl = URL(string: dataDic["logoUrl"] as! String)
        let iamgeData = try? Data(contentsOf: imageUrl!)
        cell.storeLogoImage.image = UIImage(data: iamgeData!)
        
        //title mapping
        cell.storeNameLabel.text = dataDic["name"] as? String
        
        //starRank mapping
        let starRank = dataDic["reviewAvg"] as? Double
        let simpleRank = String(format: "%.01f", starRank ?? 0)
        cell.starRankLabel.text = String(simpleRank)
        
        //review mapping
        let reviewCount = dataDic["reviewCount"] as? Int
        cell.reviewLabel.text = " · 리뷰 \(reviewCount ?? 0)"
        
        //masterReview mapping
        let ownerReplyCount = dataDic["ownerReplyCount"] as? Int
        cell.masterReviewLabel.text = " · 사장님리뷰 \(ownerReplyCount ?? 0)"
        
        
//        cell.logeImage
        return cell

    }
    
//    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
//        var padding = 0
//        for i in 0..<indexPath.section {
//            padding += self.monthSectionArr[i].0;
//        }
//
//        if(self.taskData[padding + indexPath.row].body == ""){
//            return 40;
//        }
//
//        return 200;
//    }
//
    // MARK: 해더 관련
    func numberOfSections(in tableView: UITableView) -> Int {
        return self.tableDataDic.count
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let tableDataDicKeys = Array(self.tableDataDic.keys)
        return (self.tableDataDic[tableDataDicKeys[section]]?.count)!
    }

    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        let tableDataDicKeys = Array(self.tableDataDic.keys)
        return tableDataDicKeys[section]
    }

    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 40
    }
}
