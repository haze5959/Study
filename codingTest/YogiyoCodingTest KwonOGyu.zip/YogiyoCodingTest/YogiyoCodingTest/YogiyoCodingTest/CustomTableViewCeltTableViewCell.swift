//
//  CustomTableViewCeltTableViewCell.swift
//  YogiyoCodingTest
//
//  Created by OQ on 10/02/2019.
//  Copyright © 2019 Yogiyo. All rights reserved.
//

import UIKit

class CustomTableViewCeltTableViewCell: UITableViewCell {

    @IBOutlet weak var storeLogoImage: UIImageView!
    @IBOutlet weak var storeNameLabel: UILabel!
    @IBOutlet weak var masterReviewLabel: UILabel!
    @IBOutlet weak var starRankLabel: UILabel!
    @IBOutlet weak var reviewLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
