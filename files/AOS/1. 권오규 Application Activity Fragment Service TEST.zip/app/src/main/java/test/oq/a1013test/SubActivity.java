package test.oq.a1013test;

import android.app.Activity;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

/**
 * Created by lenovo on 2016-10-18.
 */

public class SubActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Log.d("tag","서브화면 진입");

        setResult(1);//서브 엑티비티 종료되고 메인엑티비티에서 콜백 받을 값

        Intent MainParm = getIntent();

        if(MainParm.getStringExtra("textToDeliver") != null)
            Log.d("activity 값 전달 확인", MainParm.getStringExtra("textToDeliver"));

        //엑티비티 테스트 ㄱㄱ
        Button btnCallMain = (Button) findViewById(R.id.button123);
        btnCallMain.setText("엑티비티 테스트");
        btnCallMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Log.i("onClick", "엑티비티 테스트 버튼 클릭");
                Intent intentSubActivity =
                        new Intent(SubActivity.this, activityClss_Study.class);
                startActivity(intentSubActivity);
            }
        });

        //onLowMemory 테스트 ㄱㄱ
        Button btnCallMain3 = (Button) findViewById(R.id.buttonOnLowMemory);
        btnCallMain3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Log.i("onClick", "엑티비티 테스트 버튼 클릭");
                Intent intentSubActivity =
                        new Intent(SubActivity.this, OutOfMemory_Study.class);
                startActivity(intentSubActivity);
            }
        });

        //어플리케이션 클레스
        applicationClss_Study ApplicationClassStudy = (applicationClss_Study) getApplication();

        //전역 변수 메소드 실험
        Log.d("tag", ApplicationClassStudy.AppClssTest);
        ApplicationClassStudy.AppClssMethod();

        //================================================================
        //프레그먼트 클레스
        Button btnCallMain2 = (Button) findViewById(R.id.buttonFrag);
        btnCallMain2.setText("프레그먼트 테스트");
        btnCallMain2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v)
            {
                Log.i("onClick", "프레그먼트 테스트 버튼 클릭");
                Intent intentSubActivity =
                        new Intent(SubActivity.this, fragmentActivityClss_Study.class);
                startActivity(intentSubActivity);
            }
        });

        //================================================================
        //서비스 시작
        Button btn_play = (Button) findViewById(R.id.buttonStart);
        btn_play.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Service 시작",Toast.LENGTH_LONG).show();

                Intent intent = new Intent(SubActivity.this, serviceClass_Study.class);
                intent.setAction("gogo");

                startService(intent);
            }
        });

        //서비스 멈춤
        Button btn_stop = (Button) findViewById(R.id.buttonStop);
        btn_stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(getApplicationContext(),"Service 끝", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(SubActivity.this, serviceClass_Study.class);
                stopService(intent);
            }
        });

    }
}