package test.oq.a1013test;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;

import android.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.util.Log;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by lenovo on 2016-10-18.
 */

public class fragmentActivityClss_Study extends FragmentActivity {

    FragmentManager fragmentManager = getFragmentManager();
    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
    Fragment fragment1 = new fragment1();
    Fragment fragment2 = new fragment1();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_activity);

        Bundle args1 = new Bundle();
        args1.putInt("num", 1);
        args1.putString("name", "동적Fragment1");

        fragment1.setArguments(args1);
        fragmentTransaction.add(R.id.fragmentLayout1, fragment1);

        Bundle args2 = new Bundle();
        args2.putInt("num", 2);
        args2.putString("name", "동적Fragment2");

        fragmentTransaction.add(R.id.fragmentLayout2, fragment2);
        fragment2.setArguments(args2);

        fragmentTransaction.commit();
    }

    public void discardCheckBox(int num){

        fragmentTransaction = fragmentManager.beginTransaction();
        if(num == 1){
            fragmentTransaction.remove(fragment1);
        }else  {
            fragmentTransaction.remove(fragment2);
        }


        fragmentTransaction.commit();
    }
}