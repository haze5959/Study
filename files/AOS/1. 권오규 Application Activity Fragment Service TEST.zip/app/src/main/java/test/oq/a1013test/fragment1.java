package test.oq.a1013test;

import android.app.Activity;
import android.os.Bundle;
import android.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;

/**
 * Created by lenovo on 2016-10-18.
 */

public class fragment1 extends Fragment {
    fragmentActivityClss_Study mCallback;
    Bundle bundle;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        Log.d("fragment1","프레그먼트1 어테치");
        mCallback = (fragmentActivityClss_Study)activity;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        if(savedInstanceState != null) {
            for(String key : savedInstanceState.keySet()) {
                Log.d("fragment1","프레그먼트1 onCreate");
            }
        }
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Log.d("fragment1","프레그먼트1 클레스 생성");
        View view = inflater.inflate(R.layout.fragment_view, container, false);

        //엑티비티 테스트 ㄱㄱ
        CheckBox CB = (CheckBox) view.findViewById(R.id.checkBox);

        bundle = getArguments();
        String name = bundle.getString("name");
        CB.setText(name);
        CB.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v)
            {
                Log.i("onClick", "프레그먼트 테스트 버튼 클릭");
                mCallback.discardCheckBox(bundle.getInt("num"));

            }
        });
        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        if(savedInstanceState != null) {
            for(String key : savedInstanceState.keySet()) {
                Log.d("fragment1","프레그먼트1 onActivityCreated");
            }
        }
        super.onActivityCreated(savedInstanceState);

        // 뷰에 데이터를 넣는 작업 등을 할 추가할 수 있음
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d("fragment1","프레그먼트1 onStart");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("fragment1","프레그먼트1 onResume");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("fragment1","프레그먼트1 onPause");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d("fragment1","프레그먼트1 onStop");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.d("fragment1","프레그먼트1 onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();

        Log.d("fragment1","프레그먼트1 onDetach");
    }
}