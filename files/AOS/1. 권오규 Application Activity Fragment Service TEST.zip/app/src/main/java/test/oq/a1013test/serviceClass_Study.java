package test.oq.a1013test;

import android.app.Service;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.IBinder;
import android.util.Log;

public class serviceClass_Study extends Service {
    private MediaPlayer mPlayer = null;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("service", "서비스 시작");
        mPlayer = MediaPlayer.create(this, R.raw.music_oq);
        mPlayer.start();

        String result = intent.getAction();
        Log.d("intent", "인텐드 값은 ?? ~~~" + result);

        if(result == null){
            Log.d("intent", "null이다~~~~~~~~~~~~~~~~~~~");
            stopSelf();
        }
        return START_STICKY;
        //START_NOT_STICKY
        //START_REDELIVER_INTENT
    }

    @Override
    public void onDestroy() {
        Log.d("service", "서비스 제거");
        mPlayer.stop();
        super.onDestroy();
    }
}