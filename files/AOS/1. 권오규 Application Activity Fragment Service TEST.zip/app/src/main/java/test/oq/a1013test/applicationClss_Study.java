package test.oq.a1013test;

import android.app.Application;
import android.content.res.Configuration;
import android.util.Log;

/**
 * Created by lenovo on 2016-10-18.
 */

public class applicationClss_Study extends Application {

    public static String AppClssTest;
    public void AppClssMethod(){
        Log.d("application","메소드 호출 - " + AppClssTest);
    }


    private static applicationClss_Study singleton;

    public static applicationClss_Study getInstance() {
        return singleton;
    }

    @Override
    public final void onCreate() {
        super.onCreate();
        singleton = this;
        Log.d("application","어플리케이션 클레스 생성");
    }

    @Override
    public final void onTerminate() {
        super.onTerminate();
        Log.d("application","어플리케이션 클레스 종료");
    }

    @Override
    public final void onLowMemory() {
        super.onLowMemory();
        Log.d("application","어플리케이션 클레스 시스템 리소스 부족할 때");
    }

    @Override
    public final void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        Log.d("application","onConfigurationChanged 작동~===" + newConfig.toString());
    }
}

