package test.oq.a1013test;

import android.annotation.TargetApi;
import android.app.Activity;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;

/**
 * Created by lenovo on 2016-10-20.
 */

public class OutOfMemory_Study extends Activity {
    private static Drawable sBackground;
    static ImageView label;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("tag","아웃오브메모리 진입");

        //ApplicationClass memoryTest = new ApplicationClass();
        try {
            generateOOM();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    //oom
    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    public void generateOOM() throws Exception {
        //서비스 시작

        while(true) {
            label = new ImageView(this);
            if (sBackground == null) {
                sBackground = getDrawable (R.drawable.oom);
            }

            label.setBackgroundDrawable(sBackground);
            setContentView(label);
        }

    }
}
