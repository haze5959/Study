package test.oq.a1013test;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

/**
 * Created by lenovo on 2016-10-18.
 */

public class activityClss_Study extends Activity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Log.d("activity", "액티비티를 초기화");

        Button btnCallMain = (Button) findViewById(R.id.button123);
        btnCallMain.setText("메인으로 돌아가기");
        btnCallMain.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                Log.i("onClick", "메인으로 돌아가기 버튼 클릭");
                Intent intentSubActivity =
                        new Intent(activityClss_Study.this, SubActivity.class);
                startActivity(intentSubActivity);
            }

        });
    }

    // OnCreate가 종료된 후 호출 된다. UI 상태 복구에 사용된다.
    @Override
    public void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        // savedInstanceState를 이용해 UI 상태를 복구한다.
        // 이 번들은 onCreate에도 전달된다.
        Log.d("activity", "액티비티 OnCreate가 종료된 후 호출");
    }

    // 가시 수명으로 이어지기 전, 액티비티 처리를 위해 호출된다.
    @Override
    public void onRestart() {
        super.onRestart();
        Log.d("activity", "액티비티 onRestart 호출");
    }

    // 가시 수명이 시작될 때 호출된다.
    @Override
    public void onStart() {
        super.onStart();
        // 액티비티가 화면에 보임, 필요한 모든 UI 변경 사항을 적용한다.
        Log.d("activity", "액티비티 onStart 호출");
    }

    // 활성 수명이 시작될 때 호출된다.
    @Override
    public void onResume() {
        super.onResume();
        // 일시 중지된 UI 업데이트나 스레드
        // 혹은 액티비티가 비활성화되면서 잠시 중단됐던 처리를 모두 재개한다.
        Log.d("activity", "액티비티 onResume 호출");
    }

    // 활성 수명이 끝날 때, UI 상태 변화를 저장하기 위해 호출된다.
    @Override
    public void onSaveInstanceState(Bundle savedInstanceState) {
        // UI 상태 변화를 savedInstanceState에 저장한다.
        // 프로세스가 종료되고 재시작 될 경우
        // 이 번들이 onCreate에 전달될 것이다.
        super.onSaveInstanceState(savedInstanceState);
        Log.d("activity", "액티비티 onSaveInstanceState 호출");
    }

    // 활성 수명이 끝날 때 호출된다.
    @Override
    public void onPause() {
        // 액티비티가 활성 상태의 포그라운드 액티비티가 아닐 경우
        // 업데이트할 필요가 없는 UI 업데이트나 스레드
        // 혹은 CPU 사용량이 많은 처리를 일시 중단한다.
        super.onPause();

        Log.d("activity", "액티비티 onPause 호출");
    }

    // 가시 수명이 끝날 때 호출된다.
    @Override
    public void onStop() {
        // 남아있는 UI 업데이트나 스레드 혹은
        // 액티비티가 화면에 보이지 않을 때 필요치 않은 처리를 일시 중단한다.
        // 이 메서드가 호출되고 난 뒤에는 프로세스가 종료될 가능성이 있으므로
        // 바뀐 모든 내용과 상태 변화를 지속 시킨다.
        super.onStop();

        Log.d("activity", "액티비티 onStop 호출");
    }

    // 전체 수명이 끝날 때 호출된다.
    @Override
    public void onDestroy() {
        // 스레드를 종료하고, 데이터베이스 연결을 닫는 등
        // 모든 리소스를 해체한다.
        super.onDestroy();

        Log.d("activity", "액티비티 onDestroy 호출");
    }
}