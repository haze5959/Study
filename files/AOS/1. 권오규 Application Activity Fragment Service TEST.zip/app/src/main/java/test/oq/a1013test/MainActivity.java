package test.oq.a1013test;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class MainActivity extends Activity {

    static final int CALLBACK_CODE = 111;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("tag","메인 진입");

        //어플리케이션 클레스
        applicationClss_Study ApplicationClassStudy = (applicationClss_Study) getApplication();
        ApplicationClassStudy.AppClssTest = "ApplicationClass하여 값 변경했다";

        Button btnCallMain = (Button) findViewById(R.id.button123);
        btnCallMain.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v)
            {
                Log.i("onClick", "메인 버튼 클릭");
                Intent intentSubActivity = new Intent(MainActivity.this, SubActivity.class);

                //값 전달 예제
                intentSubActivity.putExtra("textToDeliver", "메인에서 전달한 값");

                //subAcitivity가 종료되면 onActivityResult 메소드가 실행!!
                startActivityForResult(intentSubActivity, CALLBACK_CODE);
            }

        });
    }

    //subActivity가 종료되고 처리되는 콜백
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        switch (requestCode){
            case CALLBACK_CODE :
                if(resultCode == 1){
                    Log.i("onActivityResult", "subActivity에서 mainActivity로 다시 돌아왔다");
                }else{
                    Log.i("onActivityResult", "실패!!!!");
                }
                break;
        }
    }
}


