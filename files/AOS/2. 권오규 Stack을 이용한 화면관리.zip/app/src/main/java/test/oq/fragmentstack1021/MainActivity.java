package test.oq.fragmentstack1021;

import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.Stack;

public class MainActivity extends FragmentActivity {

    /*
    * 권오규 Stack을 이용한 Fragment 화면 관리
    * 첫 시작 화면
    * */

    FragmentManager fragmentManager = getFragmentManager();
    FragmentTransaction fragmentTransaction = null;

    //fragment들을 담을 스택
    Stack<Fragment> FragStack = new Stack<Fragment>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //프레그먼트 생성 버튼!
        Button btnCallMain = (Button) findViewById(R.id.MainButton);
        btnCallMain.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.d("Main", "프레그먼트 생성 버튼 클릭!!");

                fragmentTransaction = fragmentManager.beginTransaction();
                Fragment fragment = new FragmentInstance();

                //번들에 담아서 생성되는 프레그먼트에 자신의 순서를 의미하는 번호를 담아서 값 전달
                Bundle args1 = new Bundle();
                args1.putInt("num", FragStack.size() + 1);
                Log.d("Fragment", "프레그먼트 " + FragStack.size() + 1 + " 생성");

                fragment.setArguments(args1);
                //생성된 프레그먼트로 화면 전환
                fragmentTransaction.replace(R.id.FragmentLayout, fragment);

                fragmentTransaction.commit();
                //commit이 안될 경우의 수가 있을수도 있으므로 push는 commit 후에 넣는 것이 바람직하다.
                FragStack.push(fragment);
            }

        });
    }
}
