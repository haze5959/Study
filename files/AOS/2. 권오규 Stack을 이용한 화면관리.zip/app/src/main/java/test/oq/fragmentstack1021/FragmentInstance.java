package test.oq.fragmentstack1021;

import android.app.Activity;
import android.app.Fragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/**
 * 프레그먼트
 */

public class FragmentInstance extends Fragment {

    //메인 엑티비티의 FragmentManager에 접근하기 위함
    MainActivity MainActivity;
    Bundle bundle;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        Log.d("fragment", "프레그먼트 어테치");
        MainActivity = (MainActivity) activity;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            for (String key : savedInstanceState.keySet()) {
                Log.d("fragment", "프레그먼트 onCreate");
            }
        }
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        Log.d("fragment", "프레그먼트 클레스 생성");
        final View view = inflater.inflate(R.layout.fragment_view, container, false);

        bundle = getArguments();
        //자신의 순서를 의미하는 변수 획득
        int num = bundle.getInt("num");

        TextView textView = (TextView) view.findViewById(R.id.textView2);
        textView.setText("Fragment " + num);

        ImageView imageView1 = (ImageView) view.findViewById(R.id.imageView);
        //사진 넣는 코드
        switch (num) {
            case 1:
                imageView1.setImageResource(R.drawable.aaa);
                break;
            case 2:
                imageView1.setImageResource(R.drawable.bbb);
                break;
            case 3:
                imageView1.setImageResource(R.drawable.ccc);
                break;
            case 4:
                imageView1.setImageResource(R.drawable.ddd);
                break;
            default:
                imageView1.setImageResource(R.drawable.eee);
                break;
        }

        //다른 프레그먼트로 이동하는 버튼 생성
        LinearLayout btLayout = (LinearLayout) view.findViewById(R.id.btnLayout);
        btLayout.removeAllViews();
        for (int i = 1; i < MainActivity.FragStack.size(); i++) {
            Button bt = new Button(view.getContext());
            bt.setText("fragment" + (i) + "로 이동");
            bt.setId(i + 1);

            final int position = i;

            bt.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast.makeText(view.getContext(), "fragment " + position, Toast.LENGTH_LONG).show();
                    //getFragmentManager().popBackStack("frag" + position, 0);
                    MainActivity.fragmentTransaction = MainActivity.fragmentManager.beginTransaction();

                    int StackSize = MainActivity.FragStack.size();
                    //이동한 Fragment보다 나중에 생긴 것들은 제거
                    for (int j = 1; j < StackSize - position; j++) {
                        //스택에서 뽑아내고 제거
                        MainActivity.fragmentTransaction.remove(MainActivity.FragStack.pop());
                        Log.d("INFO", "스택 사이즈 = " + MainActivity.FragStack.size() + "position = " + position);
                        Log.d("INFO", "제거!!~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
                    }

                    MainActivity.fragmentTransaction.replace(R.id.FragmentLayout, MainActivity.FragStack.get(position - 1));
                    MainActivity.fragmentTransaction.commit();
                }
            });
            Log.d("bt", "버튼 생성!!!!!");
            btLayout.addView(bt);
        }

        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        if (savedInstanceState != null) {
            for (String key : savedInstanceState.keySet()) {
                Log.d("fragment", "프레그먼트 onActivityCreated");
            }
        }
        super.onActivityCreated(savedInstanceState);

        // 뷰에 데이터를 넣는 작업 등을 할 추가할 수 있음
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d("fragment1", "프레그먼트 onStart");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d("fragment1", "프레그먼트 onResume");
    }

    @Override
    public void onPause() {
        super.onPause();
        Log.d("fragment1", "프레그먼트 onPause");
    }

    @Override
    public void onStop() {
        super.onStop();
        Log.d("fragment1", "프레그먼트 onStop");
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        Log.d("fragment1", "프레그먼트 onDestroyView");
    }

    @Override
    public void onDetach() {
        super.onDetach();

        Log.d("fragment1", "프레그먼트 onDetach");
    }
}