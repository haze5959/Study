package test.oq.lastchancemetro;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

/**
 * <p>Description : 술먹고 집 놓치는 부랑자가 되지 않기 위한 어플<p>
 * 메인 화면
 * @since 16년 10/28
 * @version : 1.0
 * @author  : Kwon O Gyu (haze5959@naver.com)
 */


//첫화면
public class MainActivity extends AppCompatActivity {

    //막차 검색 버튼
    private Button findMetro_btn;
    //즐겨찾기 바로가기 버튼
    private Button bookMark_btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //광고
        AdView mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        //막차 검색버튼 리스너 주입
        findMetro_btn = (Button) findViewById(R.id.findMetro_Btn);
        findMetro_btn.setOnClickListener(goFindMetro);

        //즐겨찾기 버튼 리스너 주입
        bookMark_btn = (Button) findViewById(R.id.bookMark_Btn);
        bookMark_btn.setOnClickListener(goBookMark);
    }

    //막차 검색 리스너
    View.OnClickListener goFindMetro = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Log.i("onClick", "막차 검색 버튼 클릭!");
            Intent intent = new Intent(MainActivity.this, FindMetroActivity.class);
            startActivity(intent);
        }
    };

    //즐겨찾기 리스너
    View.OnClickListener goBookMark = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Log.i("onClick", "즐겨찾기 버튼 클릭!");
            //=================================다이어로그=========================================
            final String items[] = { "평일", "토요일", "휴일" };
            AlertDialog.Builder ab = new AlertDialog.Builder(MainActivity.this);
            ab.setTitle("날짜 상태");
            ab.setSingleChoiceItems(items, -1,
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            // 각 리스트를 선택했을때
                            Toast.makeText(getApplicationContext(), items[whichButton], Toast.LENGTH_SHORT).show();
                            doStartBookMark(whichButton);
                        }
                    });
            ab.show();
            //===================================================================================

        }
    };
    /**
     *즐겨찾기로 이동하는 메소드
     * @param dayState 1.평일 2.토요일 3.휴일
     * @return 결과가 담긴 fragment 실행
     * @throws 없음
     * */
    void doStartBookMark(int dayState){
        Intent intent = new Intent(MainActivity.this, resultLastMetro.class);

        //Fragment로 보낼 리스트들
        ArrayList<String> lastMetroCodeArr = new ArrayList<String>();
        ArrayList<String> lastMetroNameArr = new ArrayList<String>();
        ArrayList<String> lastMetroLineArr = new ArrayList<String>();

        //즐겨찾기 저장한 것들을 불러오는 코드
        SharedPreferences pref = getSharedPreferences("pref", MODE_PRIVATE);
        Set<String> Metro_codeSet = new HashSet<>();
        String Metro_lineString = "{}";
        String Metro_nameString = "{}";
        Metro_codeSet = pref.getStringSet("Metro_codeSet", Metro_codeSet);
        Metro_lineString = pref.getString("Metro_lineJson", Metro_lineString);
        Metro_nameString = pref.getString("Metro_nameJson", Metro_nameString);

        try {
            JSONObject Metro_lineJson = new JSONObject(Metro_lineString);
            JSONObject Metro_nameJson = new JSONObject(Metro_nameString);

            Iterator<String> itr = Metro_codeSet.iterator();
            while( itr.hasNext() )
            {
                String temp = itr.next();
                lastMetroCodeArr.add(temp);
                lastMetroLineArr.add((String) Metro_lineJson.get(temp));
                lastMetroNameArr.add((String) Metro_nameJson.get(temp));
            }
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Log.d("test", lastMetroCodeArr.toString());
        Log.d("test", lastMetroNameArr.toString());
        Log.d("test", lastMetroLineArr.toString());

        intent.putStringArrayListExtra("Metro_code", lastMetroCodeArr);
        intent.putStringArrayListExtra("metro_name",lastMetroNameArr);
        intent.putStringArrayListExtra("metro_line",lastMetroLineArr);
        //*dayState 1 평일 / 2 토요일 / 3 휴일
        intent.putExtra("todayState", Integer.toString(dayState+1));

        startActivity(intent);
    }
}
