package test.oq.lastchancemetro.Fragment;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

import test.oq.lastchancemetro.R;

import static android.content.Context.MODE_PRIVATE;

/**
 * 막차가 얼마나 남았는지 알려준다.
 */

public class LastMetro extends Fragment {
    private int pageNum;
    private String metro_name;
    private String metro_line;
    private String lastMetroCode;
    private String dayState;
    private String result;
    ViewGroup rootView;

    URL Url;

    public static LastMetro create(int pageNumber, String lineCode, String metroName, String lineNumber, String dayState) {
        //Fragment를 생성하고 Bundle에 데이터들을 담아 보낸다.
        LastMetro fragment = new LastMetro();
        Bundle args = new Bundle();
        args.putInt("pageNum", pageNumber);
        args.putString("lineCode", lineCode);
        args.putString("metroName", metroName);
        args.putString("metroLine", lineNumber);
        args.putString("dayState", dayState);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //변수 세팅
        pageNum = getArguments().getInt("pageNum");
        metro_name = getArguments().getString("metroName");
        lastMetroCode = getArguments().getString("lineCode");
        metro_line = getArguments().getString("metroLine");
        dayState = getArguments().getString("dayState");
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = (ViewGroup) inflater.inflate(R.layout.lastmetro, container, false);

        //즐겨찾기 토글버튼
        final ToggleButton tb = (ToggleButton) rootView.findViewById(R.id.toggleButton);

        //즐겨찾기가 추가되어 있는지 없는지 판별하기 위한 구문
        SharedPreferences pref = getActivity().getSharedPreferences("pref", MODE_PRIVATE);
        Set<String> Metro_codeSet = new HashSet<>();
        Metro_codeSet = pref.getStringSet("Metro_codeSet", Metro_codeSet);
        if (Metro_codeSet.contains(lastMetroCode)) {
            tb.setChecked(true);
            tb.setBackgroundResource(android.R.drawable.star_big_on);
        }

        //즐겨찾기 토글 리스너
        tb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (tb.isChecked()) { //즐겨찾기 저장
                    tb.setBackgroundResource(android.R.drawable.star_big_on);

                    SharedPreferences pref = getActivity().getSharedPreferences("pref", MODE_PRIVATE);
                    Set<String> Metro_codeSet = new HashSet<>();
                    Metro_codeSet = pref.getStringSet("Metro_codeSet", Metro_codeSet);
                    //Metro_nameSet = pref.getStringSet("Metro_nameSet", Metro_nameSet);
                    //json으로 변환하기 위한 임시 변수
                    String StringJson_line = "{}";
                    String StringJson_name = "{}";
                    StringJson_line = pref.getString("Metro_lineJson", StringJson_line);
                    StringJson_name = pref.getString("Metro_nameJson", StringJson_name);

                    try {
                        JSONObject Metro_lineJson = new JSONObject(StringJson_line);
                        JSONObject Metro_nameJson = new JSONObject(StringJson_name);
                        Metro_lineJson.put(lastMetroCode, metro_line);
                        Metro_nameJson.put(lastMetroCode, metro_name);

                        StringJson_line = Metro_lineJson.toString();
                        StringJson_name = Metro_nameJson.toString();

                        //저장하게 처리해~~~~
                        Metro_codeSet.add(lastMetroCode);

                        SharedPreferences.Editor editor = pref.edit();
                        editor.clear();
                        editor.putStringSet("Metro_codeSet", Metro_codeSet);
                        //호선 이름은 중복이 되기 때문에 set에 저장할 수 없어서 불가피하게 일일이 저장
                        editor.putString("Metro_lineJson", StringJson_line);
                        editor.putString("Metro_nameJson", StringJson_name);
                        editor.commit();
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                } else {  //즐겨찾기 삭제
                    tb.setBackgroundResource(android.R.drawable.star_big_off);

                    SharedPreferences pref = getActivity().getSharedPreferences("pref", MODE_PRIVATE);
                    Set<String> Metro_codeSet = new HashSet<>();
                    String StringJson_line = "{}";
                    String StringJson_name = "{}";
                    Metro_codeSet = pref.getStringSet("Metro_codeSet", Metro_codeSet);
                    StringJson_line = pref.getString("Metro_lineJson", StringJson_line);
                    StringJson_name = pref.getString("Metro_nameJson", StringJson_name);

                    Metro_codeSet.remove(lastMetroCode);

                    try {

                        JSONObject Metro_lineJson = new JSONObject(StringJson_line);
                        JSONObject Metro_nameJson = new JSONObject(StringJson_name);
                        Metro_lineJson.remove(lastMetroCode);
                        Metro_nameJson.remove(lastMetroCode);
                        StringJson_line = Metro_lineJson.toString();
                        StringJson_name = Metro_nameJson.toString();

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    SharedPreferences.Editor editor = pref.edit();
                    editor.clear();
                    editor.putStringSet("Metro_codeSet", Metro_codeSet);
                    editor.putString("Metro_lineJson", StringJson_line);
                    editor.putString("Metro_nameJson", StringJson_name);
                    editor.commit();
                    Log.d("test", "즐겨찾기 지웠당");
                }
            }
        });

        //호선명을 넣을 스트링
        String lineName = "";
        //라인 이름 정보를 가지고 있는 metro_line.xml에 접근
        String[] lineNameArr = getResources().getStringArray(R.array.line);
        switch (metro_line) {
            case "1":
                lineName = lineNameArr[0];
                break;
            case "2":
                lineName = lineNameArr[1];
                break;
            case "3":
                lineName = lineNameArr[2];
                break;
            case "4":
                lineName = lineNameArr[3];
                break;
            case "5":
                lineName = lineNameArr[4];
                break;
            case "6":
                lineName = lineNameArr[5];
                break;
            case "7":
                lineName = lineNameArr[6];
                break;
            case "8":
                lineName = lineNameArr[7];
                break;
            case "9":
                lineName = lineNameArr[8];
                break;
            case "A":
                lineName = lineNameArr[9];
                break;
            case "B":
                lineName = lineNameArr[10];
                break;
            case "S":
                lineName = lineNameArr[11];
                break;
            case "I":
                lineName = lineNameArr[12];
                break;
            case "I2":
                lineName = lineNameArr[13];
                break;
            case "K":
                lineName = lineNameArr[14];
                break;
            case "U":
                lineName = lineNameArr[15];
                break;
            case "G":
                lineName = lineNameArr[16];
                break;
            case "SU":
                lineName = lineNameArr[17];
                break;
            default:
                //데이터 에러 띄우고 다시 메인화면으로 이동
                Log.e("dataError", "있을 수 없는 데이터 입니다.");
                break;
        }
        //검색한 역 라인명을 맨 위에 넣는다
        TextView textView_line = (TextView) rootView.findViewById(R.id.textView_line);
        textView_line.setText(lineName);

        //검색한 역 이름을 그다음에 넣는다
        TextView textView = (TextView) rootView.findViewById(R.id.textView);
        textView.setText(metro_name);

        //상행 내선 막차
        getLastTrain("1", dayState);
        //상행 내선 막차
        getLastTrain("2", dayState);

        return rootView;
    }

    //Http 접속을 통해 막차API 접근 메소드
    public void getLastTrain(final String inout, final String dayState) {

        new AsyncTask<Void, Void, Void>() {
            @Override
            protected void onPreExecute() {
                super.onPreExecute();
            }

            @Override
            protected Void doInBackground(Void... voids) {
                try {
                    String url_String = "http://openapi.seoul.go.kr:8088/714d65485268617a3836676b684776/json/SearchLastTrainTimeByFRCodeService/1/5/";
                    String WEEK_TAG = dayState;//1 평일/ 2 토요일 / 3 휴일
                    String INOUT_TAG = inout;//1 상행,내선/ 2 하행,외선
                    url_String = url_String + lastMetroCode + "/" + WEEK_TAG + "/" + INOUT_TAG;
                    URL Url = new URL(url_String);  // URL화 한다.

                    HttpURLConnection conn = (HttpURLConnection) Url.openConnection(); // URL을 연결한 객체 생성.

                    conn.setRequestMethod("GET"); // get방식 통신

                    InputStream is = conn.getInputStream();        //input스트림 개방

                    StringBuilder builder = new StringBuilder();   //문자열을 담기 위한 객체
                    BufferedReader reader = new BufferedReader(new InputStreamReader(is, "UTF-8"));  //문자열 셋 세팅
                    String line;

                    while ((line = reader.readLine()) != null) {
                        builder.append(line + "\n");
                    }

                    result = builder.toString();

                } catch (MalformedURLException | ProtocolException exception) {
                    exception.printStackTrace();
                } catch (IOException io) {
                    io.printStackTrace();
                }
                return null;
            }

            @Override
            protected void onPostExecute(Void aVoid) {
                super.onPostExecute(aVoid);

                //막차 정보만을 담을 제이슨
                JSONArray lastTrainJsonArr = null;

                if (result == null) {   //네트워크가 불안정할 경우
                    TextView textView = (TextView) rootView.findViewById(R.id.textView);
                    textView.setText("네트워크 불안정");
                } else {

                    try {
                        //결과 값을 제이슨으로 만든다
                        JSONObject resultJson = new JSONObject(result);
                        //도착지점과 시간이 적혀있는 지점을 다시 뽑아낸다
                        lastTrainJsonArr = new JSONArray(resultJson.getJSONObject("SearchLastTrainTimeByFRCodeService").getString("row"));

                        LinearLayout Layout = null;

                        //파라미터가 내선이라면
                        if (inout.equals("1")) {
                            Layout = (LinearLayout) rootView.findViewById(R.id.layout_inline);
                        } else {//외선이라면
                            Layout = (LinearLayout) rootView.findViewById(R.id.layout_outline);
                        }

                        for (int i = 0; i < lastTrainJsonArr.length(); i++) {
                            JSONObject jObject = lastTrainJsonArr.getJSONObject(i);

                            TextView infoText_lastTrain = new TextView(Layout.getContext());
                            infoText_lastTrain.setText(jObject.getString("SUBWAYENAME") + "행 막차");
                            infoText_lastTrain.setTextSize(25);
                            infoText_lastTrain.setBackgroundColor(Color.CYAN);
                            Layout.addView(infoText_lastTrain);

                            TextView infoText_time = new TextView(Layout.getContext());
                            infoText_time.setText(jObject.getString("LEFTTIME"));
                            infoText_time.setTextSize(25);
                            infoText_time.setBackgroundColor(Color.YELLOW);
                            Layout.addView(infoText_time);
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
            }
        }.execute();
    }

    //특정 페이지로 이동하기
    //setCurrentItem(int item, boolean smoothScroll)
}