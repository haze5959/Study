package test.oq.lastchancemetro;

import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import java.util.ArrayList;
import java.util.Set;

import test.oq.lastchancemetro.Fragment.LastMetro;

/**
 * 결과들을 담을 곳
 */

public class resultLastMetro extends FragmentActivity {
    private ViewPager mViewPager;
    private PagerAdapter mPagerAdapter;

    //전 Activity에서 넘어온 값들을 담을 리스트
    private ArrayList<String> lineCodeArr = new ArrayList<String>();
    private ArrayList<String> lineNameArr = new ArrayList<String>();
    private ArrayList<String> lineNumberArr = new ArrayList<String>();
    private  String dayState;
    //선택한 역명
    private Set<String> metroNameSet = null;

    //전체 페이지 수
    private int pageNum;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.resultlastmetro);

        //광고
        AdView mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        //전 Activity에서의 결과 반환
        Intent Param = getIntent();
        lineCodeArr = Param.getStringArrayListExtra("Metro_code");
        lineNameArr = Param.getStringArrayListExtra("metro_name");
        lineNumberArr = Param.getStringArrayListExtra("metro_line");
        dayState = Param.getStringExtra("todayState");

        //페이지 수 저장
        pageNum = lineCodeArr.size();

        mViewPager = (ViewPager) findViewById(R.id.pager);
        //만약 값이 전혀 없으면(즐겨찾기한 내용이 전혀 없다면)
        if(pageNum == 0){
            //페이지 없음을 띄운다.
            mViewPager.setBackgroundResource(R.drawable.notfound);
        }else{
            //페이저를 그린다.
            mPagerAdapter = new PagerAdapter(getSupportFragmentManager());
            mViewPager.setAdapter(mPagerAdapter);
        }
    }

    private class PagerAdapter extends FragmentPagerAdapter {

        public PagerAdapter(FragmentManager fm) {
            super(fm);
        }

        /**
         * 자동 생성된 주석
         * @param position
         * @return
         */
        @Override
        public Fragment getItem(int position) {
            // 해당하는 page의 Fragment를 생성합니다.
            return LastMetro.create(position, lineCodeArr.get(position), lineNameArr.get(position), lineNumberArr.get(position), dayState);
        }

        @Override
        public int getCount() {
            return pageNum;  // 역의 개수만큼 페이지를 보여준다.
        }
    }
}