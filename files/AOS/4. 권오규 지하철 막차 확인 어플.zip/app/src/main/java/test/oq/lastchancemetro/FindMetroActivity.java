package test.oq.lastchancemetro;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.Spinner;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

/**
 * 지하철 검색 화면
 * @since 16년 10/28
 * @version : 1.0
 * @author  : Kwon O Gyu (haze5959@naver.com)
 */


public class FindMetroActivity extends Activity {

    //지하철 전체 정보를 담을 json오브젝트
    private JSONArray metroLineArr = null;
    //해당 라인의 역코드 정보가 담겨있는 리스트
    ArrayList<String> lineCodeList = new ArrayList<String>();

    //막차 시간 검색 버튼
    private Button findLastMetro_btn;

    //평일 토요일 휴일을 구분하기 위한 라디오버튼
    private RadioButton option1;
    private RadioButton option2;
    private RadioButton option3;

    String todayState = "1";

    //라인, 역명, 역코드 담을 변수
    String metro_line = null;
    String metro_name = null;
    String metro_code = null;

    RadioButton.OnClickListener optionOnClickListener
            = new RadioButton.OnClickListener() {

        public void onClick(View v) {
            if(option1.isChecked()){
                todayState = "1";
            }else if(option2.isChecked()){
                todayState = "2";
            }else{
                todayState = "3";
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.findmetro);

        //광고
        AdView mAdView = (AdView) findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);

        option1 = (RadioButton) findViewById(R.id.radioBt_daily);
        option2 = (RadioButton) findViewById(R.id.radioBt_sata);
        option3 = (RadioButton) findViewById(R.id.radioBt_sun);
        option1.setOnClickListener(optionOnClickListener);
        option2.setOnClickListener(optionOnClickListener);
        option3.setOnClickListener(optionOnClickListener);
        option1.setChecked(true);

        try {
            //지하철 전체 정보를 담는다.
            JSONObject metroAllInfo = new JSONObject(loadJSONFromAsset());
            //역 정보만을 담은 json
            metroLineArr = new JSONArray(metroAllInfo.getString("DATA"));
        } catch (JSONException e) {
            e.printStackTrace();
        }

        //막차 시간 검색 버튼 리스너 주입
        findLastMetro_btn = (Button) findViewById(R.id.findLastMestro_Btn);
        findLastMetro_btn.setOnClickListener(findLastMetro);

        //라인 정보가 들어있는 드랍다운
        Spinner lineInfo = (Spinner)findViewById(R.id.metroline_spinner1);
        lineInfo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                    //역명이 담겨있는 드랍다운의 내용을 변경하기 위한 어뎁터
                    ArrayAdapter<String> adapter = null;

                    switch (parent.getSelectedItem().toString()){
                        case "1호선" :
                            adapter = changeSpinner("1");
                            metro_line = "1";
                            break;
                        case "2호선" :
                            adapter = changeSpinner("2");
                            metro_line = "2";
                            break;
                        case "3호선" :
                            adapter = changeSpinner("3");
                            metro_line = "3";
                            break;
                        case "4호선" :
                            adapter = changeSpinner("4");
                            metro_line = "4";
                            break;
                        case "5호선" :
                            adapter = changeSpinner("5");
                            metro_line = "5";
                            break;
                        case "6호선" :
                            adapter = changeSpinner("6");
                            metro_line = "6";
                            break;
                        case "7호선" :
                            adapter = changeSpinner("7");
                            metro_line = "7";
                            break;
                        case "8호선" :
                            adapter = changeSpinner("8");
                            metro_line = "8";
                            break;
                        case "9호선" :
                            adapter = changeSpinner("9");
                            metro_line = "9";
                            break;
                        case "공항철도" :
                            adapter = changeSpinner("A");
                            metro_line = "A";
                            break;
                        case "분당선" :
                            adapter = changeSpinner("B");
                            metro_line = "B";
                            break;
                        case "신분당선" :
                            adapter = changeSpinner("S");
                            metro_line = "S";
                            break;
                        case "인천1호선" :
                            adapter = changeSpinner("I");
                            metro_line = "I";
                            break;
                        case "인천2호선" :
                            adapter = changeSpinner("I2");
                            metro_line = "I2";
                            break;
                        case "경의 중앙선" :
                            adapter = changeSpinner("K");
                            metro_line = "K";
                            break;
                        case "의정부 경전철" :
                            adapter = changeSpinner("U");
                            metro_line = "U";
                            break;
                        case "경춘천" :
                            adapter = changeSpinner("G");
                            metro_line = "G";
                            break;
                        case "수인선" :
                            adapter = changeSpinner("SU");
                            metro_line = "SU";
                            break;
                        default:
                            //데이터 에러 띄우고 다시 메인화면으로 이동
                            Log.e("dataError", "있을 수 없는 데이터 입니다.");
                            break;
                    }
                    //역명 드랍다운 다시 초기화
                    Spinner nameInfo = (Spinner)findViewById(R.id.metroline_spinner2);
                    nameInfo.setAdapter(adapter);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Log.d("debug", "아무것도 선택 안함");
            }
        });

        //역명 정보가 들어있는 드랍다운
        Spinner nameInfo = (Spinner)findViewById(R.id.metroline_spinner2);
        nameInfo.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                metro_name = parent.getSelectedItem().toString();
                metro_code = lineCodeList.get(position);
                Log.d("FindMetroActivity", "역명 - " + metro_name);
                Log.d("FindMetroActivity", "역명 코드 - " + metro_code);
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                Log.d("debug", "아무것도 선택 안함");
            }
        });


    }

    //막차 찾기 리스너
    View.OnClickListener findLastMetro = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            Log.i("onClick", "막차시간 검색 버튼 클릭!");
            Log.i("selectInfo", "라인 => " + metro_line);
            Log.i("selectInfo", "역명 => " + metro_name);
            Log.i("selectInfo", "역코드 => " + metro_code);

            Intent intent = new Intent(FindMetroActivity.this, resultLastMetro.class);
            ArrayList<String> lastMetroCodeArr = new ArrayList<String>();
            ArrayList<String> lastMetroNameArr = new ArrayList<String>();
            ArrayList<String> lastMetroLineArr = new ArrayList<String>();

            lastMetroCodeArr.add(metro_code);
            lastMetroNameArr.add(metro_name);
            lastMetroLineArr.add(metro_line);

            //지하철 역 이름과 코드를 전달(북마크 기능에서는 여러개를 받을 수도 있기 때문에 ArrayList로 받게되어 있음)
            intent.putStringArrayListExtra("Metro_code", lastMetroCodeArr);
            intent.putStringArrayListExtra("metro_name",lastMetroNameArr);
            intent.putStringArrayListExtra("metro_line",lastMetroLineArr);
            intent.putExtra("todayState", todayState);


            startActivity(intent);
        }
    };

    //json 파일을 로드하기 위한 메소드
    public String loadJSONFromAsset() {
        String json = null;
        try {

            InputStream is = getAssets().open("metro_info.json");
            int size = is.available();
            byte[] buffer = new byte[size];
            is.read(buffer);
            is.close();
            json = new String(buffer, "UTF-8");

        } catch (IOException ex) {
            ex.printStackTrace();
            return null;
        }
        return json;

    }

    //지하철 정보 json 파일을 파싱하고 spinner에 끼워넣을 어뎁터를 리턴한다.
    public ArrayAdapter changeSpinner(String num){
        //선택한 호선을 넣을 리스트
        ArrayList<String> lineList = new ArrayList<String>();
        //역코드 리스트들 초기화
        lineCodeList.clear();
        try {
            for(int i = 0; i < metroLineArr.length(); i++){
                JSONObject jObject = metroLineArr.getJSONObject(i);

                if(jObject.getString("LINE_NUM").equals(num)){
                    lineList.add(jObject.getString("STATION_NM"));
                    lineCodeList.add(jObject.getString("FR_CODE"));
                }
            }

            //정렬
            for(int i = 0; i < lineList.size() - 1; i++){
                for(int j = 0; j < lineList.size() - 1 - i; j++){
                    if(lineList.get(j).compareTo(lineList.get(j + 1)) == 0 || lineList.get(j).compareTo(lineList.get(j + 1)) > 0){
                        String temp_name = lineList.get(j);
                        String temp_code = lineCodeList.get(j);

                        lineList.set(j, lineList.get(j + 1));
                        lineCodeList.set(j, lineCodeList.get(j + 1));

                        lineList.set(j + 1, temp_name);
                        lineCodeList.set(j + 1, temp_code);
                    }
                }
            }
       } catch (JSONException e) {
            e.printStackTrace();
        }
        return new ArrayAdapter<String>(getApplicationContext(), android.R.layout.simple_spinner_item, lineList);
    }
}
